app_name = 'scienceApp'
urlpatterns = [

]
