from django.shortcuts import render

# Create your views here.
from django.urls import path
 
from scienceApp import views
 
app_name = 'scienceApp'  # app的名字
urlpatterns = [
    path('science/', views.science, name='science')  # 路由访问的路径，name为反向解析时用到
 
]