from django.apps import AppConfig


class ScienceappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scienceApp'
