app_name = 'serviceApp'
urlpatterns = [

]
