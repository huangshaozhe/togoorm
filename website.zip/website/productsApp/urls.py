app_name = 'productsApp'
urlpatterns = [

]
