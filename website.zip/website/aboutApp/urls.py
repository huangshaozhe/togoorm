app_name = 'aboutApp'
urlpatterns = [

]
