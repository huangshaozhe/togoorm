app_name = 'newsApp'
urlpatterns = [

]
